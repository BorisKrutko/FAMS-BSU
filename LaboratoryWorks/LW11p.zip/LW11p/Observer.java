package LW11p;

public interface Observer {
    void update(char key);
}
