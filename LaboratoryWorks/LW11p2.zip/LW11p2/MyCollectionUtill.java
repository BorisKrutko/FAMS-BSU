package LW11p2;

public interface MyCollectionUtill {
    public String mapToString();
    public String mapToStringAtRate(int rate);
    public String listToString();
}
