package LW11p2;

public class Main {
    public static void main(String[] args) {
        new MyFrame();
    }
}